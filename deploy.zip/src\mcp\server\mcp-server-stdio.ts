import 'dotenv/config'
import { MCPServer } from "./mcp-server"

// Start the server
const server = new MCPServer()
console.error('NSE India MCP Server started')